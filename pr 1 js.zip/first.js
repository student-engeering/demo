
const student = {
    name : "ahmad",
    age : 21,
    marks : 89,
    status : "pass",
};

console.log(student)